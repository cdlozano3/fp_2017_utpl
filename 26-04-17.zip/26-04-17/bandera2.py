def banderaDos():  # Módulo 
	""" Ingresar por telado un valor y sumarlo hasta que el ususario desee e imrimir mensaje"""
	# Declaración de vriables e inicialización
	bandera, valor, suma, m = True, 0, 0, 0
	# Proceso
	while bandera == True:
		valor = int(input("Ingrese el valor a sumar: "))
		suma = suma + valor
		cadena = ("Valores ingresados", valor)
		cadena_final = cadena_final + cadena
		m = input("Ingrese -1 para salir: ")
		if m == "-1":
			bandera = False
	print(cadena_final)
	print("Valor final {0}" .format(suma))  # Salida de datos
