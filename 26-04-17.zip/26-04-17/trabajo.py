def trabajo():
	""" ingresar e imprimir los datos de una persona"""
	# Declaración e inicialización de variables
	nombre, apellido, edad, ciudad = "", "", 0, ""
	nombre = input("Ingrese sus Nombres: ")  # entrada de datos
	nombre = nombre.upper()  # Conversión de la cadena en Mayuscula
	apellido = input("Ingrese sus apellidos: ")
	edad = int(input("Ingrese su edad: "))
	ciudad = input("Ingrese la ciudad en donde reside: ")
	ciudad = ciudad.upper()
	anio = 2017 - edad
	# Salida da datos
	print("Datos personales\n Nombres:\n\t{0}\n Apellidos:\n\t{1}\n Edad:\n\t{2}\nAño de nacimiento:\n\t{3}\n Ciudad:\n\t{4}".format(nombre, apellido, edad, anio, ciudad))
