def limite():
	"""calcular el límite de un ciclo"""
	cont, suma = 1, 0
	limt = int(input("Ingrese el límite del ciclo: "))  # Entrada da datos
	while cont <= limt:  # Proceso
		suma = suma + cont
		cont = cont + 1
	print("La suma total es {0}".format(suma))  # Salida de datos