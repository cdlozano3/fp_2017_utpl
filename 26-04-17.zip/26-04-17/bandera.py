def bandera():  # Módulo 
	"""  Valores booleanos aplicando if """
	# Declaración de vriables e inicialización
	bandera, valor, suma, m = True, 0, 0, 0
	# Proceso
	while bandera == True:
		valor = int(input("Ingrese el valor a sumar: "))
		suma = suma + valor
		m = input("Ingrese -1 para salir: ")
		if m == "-1":
			bandera = False
	print("Valores sumados igual a", suma)  # Salida de datos