def datos():  # Usamos un módulo 
	""" Imprimir datos"""
	nombre = "Cristian" # Se le asigna un valor a la variable
	apellido = "Lozano"
	print("Mi nombre es:")  # Salida de datos 
	print("	", nombre)
	