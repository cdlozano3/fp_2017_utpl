def SumaNumeros():  # Módulo, el cuál se va a ejecutar en la consola 
	"""Suma de dos números"""
	num1 = 10
	num2 = 20
	# Operación
	sum = num1 + num2
	print(sum)
	