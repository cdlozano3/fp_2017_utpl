def PrimerProyecto():
	print("Hola mundo")