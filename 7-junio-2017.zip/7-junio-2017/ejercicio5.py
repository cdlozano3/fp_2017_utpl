def ejercicio5():
	""" hola"""
	notas = [[7, 7, 8], [9,8,10],[10,10,3]]
	suma = 0
	for i in range(0, 3):
		for k in range(0, 3):
			if (i == k):
				suma = suma + notas[i][k]

	print("La suma es %d\t" %suma)			
