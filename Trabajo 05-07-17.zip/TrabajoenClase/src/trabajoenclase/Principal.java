/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabajoenclase;

/**
 *
 * @author Salas
 */
public class Principal {
    public static void main(String[] args) {
        Estudiante e = new Estudiante();
        Estudiante e2 = new Estudiante();
        int sum_edad;
        double prom;
        // e.nombre = "Luis";
        // e2.nombre ="María";
        
//        e.agregar_nombre("Luis");
//        sum_edad = e.edad + e2.edad;
//        prom = (double)sum_edad / 2;
//        System.out.println(prom);
    }
}
