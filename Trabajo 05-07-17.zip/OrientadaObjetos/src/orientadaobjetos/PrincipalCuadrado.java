/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package orientadaobjetos;
import java.util.Scanner;
/**
 *
 * @author Salas
 */
public class PrincipalCuadrado {
     public static void main(String[] args) {
        Scanner e = new Scanner(System.in);        
        int med_lado;
        for(int c = 1;c <= 5; c++){           
            System.out.println("Agrege la medida del lado del cuadrado: ");
            med_lado = e.nextInt();
            Cuadrado cuad = new Cuadrado();
            cuad.agregar_lado(med_lado);  
            int area = cuad.calcular_area();
            int perimetro = cuad.calcular_perimetro();
            System.out.printf("Cuadrado con lado %d\n\tÁrea = %d\n\tPerimetro = %d\n", cuad.obtener_lado(), area, perimetro);
 
        }
     }
}
