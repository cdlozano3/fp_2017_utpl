/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package orientadaobjetos;

/**
 *
 * @author Salas
 */
public class Principal {
     public static void main(String[] args) {
        Estudiante e = new Estudiante();
        Estudiante e2 = new Estudiante();
        int sum_edad;
        double prom;
        String Valor_nombre ="Luis";
        e.agregar_nombre(Valor_nombre);
        e2.agregar_nombre("María");
        e.agregar_edad(18);
        e2.agregar_edad(17);
        sum_edad = e.obtener_edad() + e2.obtener_edad();
        prom = (double)sum_edad /2;
        System.out.println(e.Obtener_nombre());
        System.out.println(prom);
    }
}
