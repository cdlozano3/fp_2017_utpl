/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package orientadaobjetos;

/**
 *
 * @author Salas
 */
public class Estudiante {
    private String nombre;
    private int edad;
    
    public void agregar_nombre(String n){
        nombre = n;
        
    }
    
    public String Obtener_nombre(){
        return nombre;
    }
    public void agregar_edad(int e){
        if(e < 18){
            edad = 18;
        }else{
            edad = e;
        }
        
    }
    public int obtener_edad(){
        return edad;
    }
}
