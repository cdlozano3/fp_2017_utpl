def conversion():
	""" Convertir datos tipo int a datos tipo float"""
	a = int(input("Ingrese el valor de a:"))  # Entrada de datos por el Usuario
	b = int(input("Ingrese el valor de b:"))
	c = int(input("Ingrese el valor de c:"))  # Los valores que se ingresan son enteros
	# Conversión de datos enteros a float
	a = float(a)
	b = float(b)
	c = float(c)
	# Operación correspondiente
	x = 10 / a + b - 3 * c 
	# Salida de datos
	print ("Mi resultado es", "{0:.2f}".format(x))


