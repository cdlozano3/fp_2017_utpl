def edad():
	""" Ingresar mi edad y altura e imprimirlos"""
	# El valor de la vriable la ungresará el usuario
	edad = int(input("Ingrese su edad:"))
	altura = input("Ingrese su altura:")
	# Salida de datos 
	print("Su edad es", edad, "y su altura es", altura)
	print()
