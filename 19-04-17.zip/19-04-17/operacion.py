def operacion():
	""" Pedir el valor de 3 variables, sumarlas e imorimir un mensaje con el resultado"""
	a = int(input("Ingrese el valor de a:"))  # Entrada de datos por el Usuario
	b = int(input("Ingrese el valor de b:"))
	c = int(input("Ingrese el valor de c:"))
	# Operación correspondiente
	x = 10 / a + b - 3 * c 
	# Salida de datos
	print ("Mi resultado es", x)
	
