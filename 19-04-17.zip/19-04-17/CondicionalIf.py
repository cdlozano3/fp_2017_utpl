def CondicionalIf():
	"""Aplicación de Condicional If"""
	valor = 11  # Declaración e inicialización de variables
	if valor >= 7 and valor <= 10:  # Condicional If 
		print("Aprobado con", valor)
	else:
		print("Reprobado con", valor)
	print()
