from Estudiante1 import Estudiante

estudiante_1 = Estudiante()
estudiante_2 = Estudiante()

suma_edades = 0
promedio = 0
valor_nomb = "Luis"

estudiante_1.agregar_nombre(valor_nomb)
estudiante_1.agregar_edad(18)
estudiante_2.agregar_edad(17)

suma_edades = estudiante_1.obtener_edad() + estudiante_2.obtener_edad()

promedio = (float(suma_edades) / 2)

print(promedio)

input()
