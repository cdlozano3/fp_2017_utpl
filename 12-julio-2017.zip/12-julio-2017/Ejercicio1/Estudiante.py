class Estudiante:
    nomb = ""
    edad = 0
    
