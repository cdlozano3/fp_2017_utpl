from Estudiante import Estudiante

estudiante_1 = Estudiante()
estudiante_2 = Estudiante()
suma_tot = 0
promedio = 0

estudiante_1.nombre = "Luis"
estudiante_2.nombre = "Maria"

estudiante_1.edad = 18
estudiante_2.edad = 17

suma_tot = estudiante_1.edad + estudiante_2.edad
promedio = (float(suma_tot) / 2)

print (promedio)

input ()
