from Ciudad import Ciudad1

suma = 0
c1 =  Ciudad1()
c1.agregar_nombre("Loja")
c1.agregar_poblacion_mujeres(8000)
c1.agregar_poblacion_hombres(9500)

c2 =  Ciudad1()
c2.agregar_nombre("Guayaquil")
c2.agregar_poblacion_mujeres(30000)
c2.agregar_poblacion_hombres(30500)
        
c3 =  Ciudad1()
c3.agregar_nombre("Quito")
c3.agregar_poblacion_mujeres(31000)
c3.agregar_poblacion_hombres(31500)
        
c4 = Ciudad1()
c4.agregar_nombre("Cuenca")
c4.agregar_poblacion_mujeres(10000)
c4.agregar_poblacion_hombres(12800)
        
c5 = Ciudad1()
c5.agregar_nombre("Zamora")
c5.agregar_poblacion_mujeres(6000)
c5.agregar_poblacion_hombres(7200)

suma = c1.obtener_poblacion() + c2.obtener_poblacion() + c3.obtener_poblacion()+ c4.obtener_poblacion() + c5.obtener_poblacion() 
      
print("La suma de las 5 ciudades es:\n\t",suma)

input()

