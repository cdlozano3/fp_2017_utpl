def arreglos3():
	"""Imprimir los datos que se piden acerca de los partidos en una semana"""
	suma = 0
	promedio = 0
	respuestas = [0,0,0,0,0,0,0]
	dias = ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"]
	for i in range(0, 7):
		respuestas[i] = int(input("Número de partidos jugados el día %s\n" % dias[i]))
	print("-----------------------------------------")
	for i in range(0, 7):
		suma = suma + respuestas[i]
	promedio = suma / len(respuestas)
	print("El promedio de partidos jugados es %.2f\n" % promedio)
