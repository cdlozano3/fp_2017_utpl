def arreglos2():
	""" ejercicio con arreglos y suma"""
	c = [11,22,43,14]
	suma = 0
	for i in range(0, 4):
		suma = suma + c[i]

	print(suma)

