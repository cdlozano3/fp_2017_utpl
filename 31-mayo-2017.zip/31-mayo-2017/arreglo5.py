def arreglo5():
	"""sumar las notas de las materias y sacar un promedio con arreglos"""
	suma = 0
	promedio = 0
	notas = [0,0,0,0]
	materias = ["Programación", "Base de datos", "Contabilidad", "Biologia"]
	for i in range(0, 4):
		notas[i] = input("Ingrese la nota de %s:\n " % materias[i])

	print("---------------------------------")
	for i in range(0,4):
		print("La nota de %s fue %s\n " % (materias[i], notas[i]))
	for i in range(0, 4):
		suma = suma + int(notas[i])

	promedio = suma / len(notas)
	print("El promedio de notas es %.2f\n " % promedio)
	if(promedio >= 80):
		print("Su promedio es: Sobresaliente")
	if(promedio < 80 and promedio >= 60):
		print("Su promedio es: bueno")
	if(promedio < 60):
		print("Su promedio es: regular")
