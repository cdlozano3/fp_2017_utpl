def arreglos():
	""" ejercicio con arreglos e impresion de la posicion"""
	c = [0, 0, 0, 0, 0]
	for i in range(0, 5):
		print("Posición: %d - Valor: %d\n" %(i, c[i]))

