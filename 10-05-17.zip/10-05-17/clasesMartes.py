def clasesMartes():
	""" Ciclo for"""
	for cont in range(1,11):  # Proceso
		print("{0}".format(cont))

