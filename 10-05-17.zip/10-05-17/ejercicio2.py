def ejercicio2():
	"""Imprimir una cadena"""
	cadena = ""  # Declaración e inicialización de variables
	for cont in range(1,11):  # Proceso
		cadena = cadena + "{0}\t\t{1}\n".format(cont, cont + 10)
	print(cadena)  # Salida de datos
