def ejercicio1():
	"""Decidir e usuario si quiere la respuesta horizontal o vertical"""
	tipo = input(" Desea la respuesta vertical(1) o horizontal(2): ")  # Entrada de datos
	for cont in range(1,11):  # Proceso de datos
		if(tipo == 1):
			print("{0}\n".format(cont))
		if(tipo == 2):
			print("{0}\t".format(cont))