def newClass():
	"""Imprimir una tabla usando comandos"""
	#Declaración e inicialización de variables
	cadena = ""
	suma1, suma2 = 0, 0
	cadena = cadena + "{0}\t\t{1}\n".format("Valor", "Resultado")
	for cont in range(1,11):  # Proceso
		suma1 = suma1 + cont
		aux = cont + 10
		suma2 = suma2 + aux
		cadena = cadena + "{0}\t\t{1}\n".format(cont, aux)
	print(cadena)  # Salida de datos
	print("\n{0}".format("Total"))
	print("\n{0}\t\t{1}".format(suma1, suma2))