def ejercicio3():
	""" Imprimir una tabla"""
	# Declaración e inicialización de variables
	cadena = ""
	# Entrada de datos
	cadena = cadena + "{0}\t\t{1}\n".format("Valor", "Resultado")
	for cont in range(1,11):  # Proceso
		cadena = cadena + "{0}\t\t{1}\n".format(cont, cont + 10)
	print(cadena)  # Salida de datos
	
