# importar modulo 
import trabajador

# variables
nombre = "Luis"
apellido = "Romero"
cedula = "115545545"
edad = 40
sueldo_neto = 500.2

trabajador.generar_recibo(nombre, apellido, cedula, edad, sueldo_neto)
   